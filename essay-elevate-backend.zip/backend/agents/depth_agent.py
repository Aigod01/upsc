async def evaluate_depth(essay: str) -> dict:
    score = 8
    reason = "It demonstrates deep understanding and analysis."
    return {"score": score, "reason": reason}
