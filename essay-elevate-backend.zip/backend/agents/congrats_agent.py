async def get_congrats() -> str:
    return "🎉 Congratulations! Your essay meets the UPSC standard."
