async def evaluate_language(essay: str) -> dict:
    score = 7
    reason = "Language is mostly formal and grammatically sound."
    return {"score": score, "reason": reason}
