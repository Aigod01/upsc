async def get_suggestions(essay: str) -> list:
    return [
        "Improve sentence structure.",
        "Use more factual data.",
        "Avoid repetitive points."
    ]
