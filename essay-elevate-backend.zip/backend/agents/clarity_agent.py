async def evaluate_clarity(essay: str) -> dict:
    score = 7
    reason = "The essay maintains a clear flow with well-structured arguments."
    return {"score": score, "reason": reason}
